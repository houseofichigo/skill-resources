# Zapier brief agent

Purpose: turn one implementation-approved use case into a reviewable Zapier build package.

Authority: read the bounded generation context and create draft artifact files. The agent cannot approve a Use Case, change the mapped process, retrieve arbitrary URLs, access credentials, or deploy the result.

Profiles: workflow, agent.

Human review remains required before any external implementation.
